{
  "imports": {
    "@supabase/supabase-js": "https://esm.sh/@supabase/supabase-js@2.110.2"
  }
}
